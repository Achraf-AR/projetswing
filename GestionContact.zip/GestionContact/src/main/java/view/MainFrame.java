package view;

import controller.ContactManager;
import controller.VoiceInput;
import model.Personne;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.event.DocumentListener;

public class MainFrame extends JFrame {

    private ContactManager manager;
    private DefaultListModel<Personne> model;
    private JList<Personne> contactList;
    private JTextField searchField;

    public MainFrame() {
        manager = new ContactManager();
        setTitle("Gestion de Contacts");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700, 500);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(240, 248, 255));
        setLayout(new BorderLayout(10, 10));

        // Search bar
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        searchField = new JTextField();
        searchField.setFont(new Font("Arial", Font.PLAIN, 14));
        topPanel.add(new JLabel("🔍 Recherche: "), BorderLayout.WEST);
        topPanel.add(searchField, BorderLayout.CENTER);
        add(topPanel, BorderLayout.NORTH);

        // Ajout du listener pour la recherche
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                filterContacts();
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                filterContacts();
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                filterContacts();
            }
        });

        // Contact list
        model = new DefaultListModel<>();
        for (Personne p : manager.getContacts()) {
            model.addElement(p);
        }
        contactList = new JList<>(model);
        contactList.setCellRenderer(new ContactRenderer());
        JScrollPane scrollPane = new JScrollPane(contactList);
        scrollPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        add(scrollPane, BorderLayout.CENTER);

        // Buttons Panel
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        btnPanel.setBackground(new Color(224, 255, 255));

        JButton addBtn = new JButton("➕ Ajouter Contact");
        JButton voiceBtn = new JButton("🎤 Ajouter par Voix");
        JButton deleteBtn = new JButton("🗑️ Supprimer Contact");

        addBtn.setFocusPainted(false);
        voiceBtn.setFocusPainted(false);
        deleteBtn.setFocusPainted(false);

        addBtn.addActionListener(this::addContact);
        voiceBtn.addActionListener(this::addContactVoice);
        deleteBtn.addActionListener(this::deleteContact);

        btnPanel.add(addBtn);
        btnPanel.add(voiceBtn);
        btnPanel.add(deleteBtn);
        add(btnPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void addContact(ActionEvent e) {
        JTextField nomField = new JTextField();
        JTextField prenomField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField telField = new JTextField();
        JButton selectPhotoBtn = new JButton("Choisir une photo");
        JLabel selectedPhotoLabel = new JLabel("Aucune sélection");

        JPanel panel = new JPanel(new GridLayout(0, 1, 5, 5));
        panel.add(new JLabel("Nom:"));
        panel.add(nomField);
        panel.add(new JLabel("Prénom:"));
        panel.add(prenomField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Téléphone:"));
        panel.add(telField);
        panel.add(selectPhotoBtn);
        panel.add(selectedPhotoLabel);

        final String[] selectedImage = {""};

        selectPhotoBtn.addActionListener(evt -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setCurrentDirectory(new File("."));
            fileChooser.setFileFilter(new FileNameExtensionFilter("Images", "jpg", "jpeg", "png", "gif"));
            int result = fileChooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                selectedImage[0] = "resources/images/" + file.getName();
                selectedPhotoLabel.setText(file.getName());
                File dest = new File(selectedImage[0]);
                if (!dest.exists()) {
                    file.renameTo(dest);
                }
            }
        });

        int result = JOptionPane.showConfirmDialog(this, panel, "Ajouter Contact", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            if (nomField.getText().trim().isEmpty() || prenomField.getText().trim().isEmpty()
                    || emailField.getText().trim().isEmpty() || telField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "❗ Tous les champs doivent être remplis pour ajouter un contact.", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Personne p = new Personne(
                nomField.getText(),
                prenomField.getText(),
                emailField.getText(),
                telField.getText(),
                selectedImage[0].isEmpty() ? "resources/images/user.png" : selectedImage[0]
            );
            manager.addContact(p);
            model.addElement(p);
        }
    }

    private void addContactVoice(ActionEvent e) {
        VoiceInput voice = new VoiceInput();

        JOptionPane.showMessageDialog(this, "🎤 Parlez pour saisir le NOM...");
        String nom = voice.listen();
        JOptionPane.showMessageDialog(this, "✅ Vous avez dit : " + nom);

        JOptionPane.showMessageDialog(this, "🎤 Parlez pour saisir le PRÉNOM...");
        String prenom = voice.listen();
        JOptionPane.showMessageDialog(this, "✅ Vous avez dit : " + prenom);

        JOptionPane.showMessageDialog(this, "🎤 Parlez pour saisir l'EMAIL...");
        String email = voice.listen();
        JOptionPane.showMessageDialog(this, "✅ Vous avez dit : " + email);

        JOptionPane.showMessageDialog(this, "🎤 Parlez pour saisir le TÉLÉPHONE...");
        String tel = voice.listen();
        JOptionPane.showMessageDialog(this, "✅ Vous avez dit : " + tel);

        if (nom.trim().isEmpty() || prenom.trim().isEmpty() || email.trim().isEmpty() || tel.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "❗ Tous les champs doivent être remplis pour ajouter un contact.", "Erreur", JOptionPane.ERROR_MESSAGE);
            voice.stop();
            return;
        }

        Personne p = new Personne(nom, prenom, email, tel, "resources/images/user.png");
        manager.addContact(p);
        model.addElement(p);

        voice.stop();
    }

    private void deleteContact(ActionEvent e) {
        Personne selected = contactList.getSelectedValue();
        if (selected != null) {
            manager.removeContact(selected);
            model.removeElement(selected);
        }
    }

    // La méthode pour filtrer les contacts selon le texte de recherche
    private void filterContacts() {
        String searchText = searchField.getText().toLowerCase();
        DefaultListModel<Personne> filteredModel = new DefaultListModel<>();

        for (Personne p : manager.getContacts()) {
            if (p.getNom().toLowerCase().contains(searchText) ||
                p.getPrenom().toLowerCase().contains(searchText) ||
                p.getEmail().toLowerCase().contains(searchText) ||
                p.getTelephone().toLowerCase().contains(searchText)) {
                filteredModel.addElement(p);
            }
        }

        contactList.setModel(filteredModel);
    }

    static class ContactRenderer extends JPanel implements ListCellRenderer<Personne> {

        private JLabel photoLabel = new JLabel();
        private JLabel textLabel = new JLabel();

        public ContactRenderer() {
            setLayout(new BorderLayout(10, 10));
            setBorder(new EmptyBorder(5, 5, 5, 5));
            add(photoLabel, BorderLayout.WEST);
            add(textLabel, BorderLayout.CENTER);
            setBackground(Color.WHITE);
        }

        @Override
        public Component getListCellRendererComponent(JList<? extends Personne> list, Personne value, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            // Charger la photo avec vérification
            ImageIcon icon;
            File imageFile = new File(value.getPhotoPath());
            if (imageFile.exists()) {
                icon = new ImageIcon(value.getPhotoPath());
            } else {
                icon = new ImageIcon("resources/images/user.png");
            }
            Image img = icon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
            photoLabel.setIcon(new ImageIcon(img));

            // Texte formaté
            textLabel.setText("<html><b>" + value.getPrenom() + " " + value.getNom() + "</b><br/>"
                    + "📧 " + value.getEmail() + "<br/>"
                    + "📞 " + value.getTelephone() + "</html>");
            textLabel.setFont(new Font("Arial", Font.PLAIN, 14));

            if (isSelected) {
                setBackground(new Color(173, 216, 230));
            } else {
                setBackground(Color.WHITE);
            }

            return this;
        }
    }
}
