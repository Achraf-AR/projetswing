package controller;

import edu.cmu.sphinx.api.Configuration;
import edu.cmu.sphinx.api.LiveSpeechRecognizer;
import edu.cmu.sphinx.api.SpeechResult;

public class VoiceInput {

    private LiveSpeechRecognizer recognizer;

    public VoiceInput() {
        try {
            Configuration config = new Configuration();
            config.setAcousticModelPath("resource:/edu/cmu/sphinx/models/en-us/en-us");
            config.setDictionaryPath("resource:/edu/cmu/sphinx/models/en-us/cmudict-en-us.dict");
            config.setLanguageModelPath("resource:/edu/cmu/sphinx/models/en-us/en-us.lm.bin");

            recognizer = new LiveSpeechRecognizer(config);
            recognizer.startRecognition(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String listen() {
        if (recognizer != null) {
            SpeechResult result = recognizer.getResult();
            if (result != null) {
                return result.getHypothesis();
            }
        }
        return "";
    }

    public void stop() {
        if (recognizer != null) {
            recognizer.stopRecognition();
        }
    }
}
