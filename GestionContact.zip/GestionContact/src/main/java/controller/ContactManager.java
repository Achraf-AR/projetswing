package controller;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import model.Personne;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class ContactManager {
    private static final String FILE_NAME = "contacts.json";
    private static final String IMAGES_FOLDER = "images"; // Dossier des images
    private List<Personne> contacts;

    public ContactManager() {
        ensureImagesFolderExists(); // Vérifie que le dossier images existe
        contacts = loadContacts();
    }

    public List<Personne> getContacts() {
        return contacts;
    }

    public void addContact(Personne personne) {
        contacts.add(personne);
        saveContacts();
    }

    public void removeContact(Personne personne) {
        contacts.remove(personne);
        saveContacts();
    }

    private void saveContacts() {
        try (Writer writer = new FileWriter(FILE_NAME)) {
            new Gson().toJson(contacts, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private List<Personne> loadContacts() {
        try (Reader reader = new FileReader(FILE_NAME)) {
            Type listType = new TypeToken<ArrayList<Personne>>() {}.getType();
            List<Personne> loadedContacts = new Gson().fromJson(reader, listType);
            if (loadedContacts == null) {
                return new ArrayList<>();
            }
            return loadedContacts;
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    private void ensureImagesFolderExists() {
        try {
            if (!Files.exists(Paths.get(IMAGES_FOLDER))) {
                Files.createDirectory(Paths.get(IMAGES_FOLDER));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
